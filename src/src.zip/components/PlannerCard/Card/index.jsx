import React from "react";
import Headline from "../../../assets/FontSystem/Headline";
import { FontSubtitle } from "../../../assets/FontSystem/styles";
import Subtitle from "../../../assets/FontSystem/Subtitle";

import {
  ContainerCards,
  DivStatus,
  Horas,
  Setor,
  ReleaseTrain,
  UserName,
  EmailClient,
  EmailUser,
  Status,
  DivPhoto,
  Client,
  Guests,
  PositionStatus,
  DivTextCard,
  TextClient,
  TextEmail,
  TextGuests,
} from "./styles";
const Card = (props) => {
  return (
    <>
      <ContainerCards>
        <Setor>
            <Headline mode={"HeadLine5"} name={props.subject}/>
        </Setor>
        <ReleaseTrain>
            <Subtitle mode={"TitleMed"} name={props.releaseTrain} colorFont={"#007BFF"}/>
        </ReleaseTrain>

        <DivTextCard>
          <TextClient>
            <Subtitle mode={"TitleMed"} name={"Client:"} colorFont={"#1E2222"}/>
            <Subtitle mode={"TitleMed"} name={props.client} colorFont={"#888888"}/>
          </TextClient>
          <TextEmail>
            <Subtitle mode={"TitleMed"} name={"Client:"} colorFont={"#1E2222"}/>
            <Subtitle mode={"TitleMed"} name={props.client} colorFont={"#888888"}/>
          </TextEmail>
          <TextGuests>
            <Subtitle mode={"TitleMed"} name={"Client:"} colorFont={"#1E2222"}/>
            <Subtitle mode={"TitleMed"} name={props.client} colorFont={"#888888"}/>
          </TextGuests>
          
          
        </DivTextCard> 
          
        
        
        <EmailClient>{props.emailClient}</EmailClient>
        <Guests>{props.guests}</Guests>
        <DivStatus $mode={props.status}/>
        <Horas>11:00 - 12:00</Horas>
        <DivPhoto/>
        <UserName>{props.userName}</UserName>
        <EmailUser>{props.emailUser}</EmailUser>
        <Status $mode={props.status}>
          <PositionStatus>
            <Subtitle mode={"TextDescription2"} name={props.status} colorFont={"#1E2222"}/>
          </PositionStatus>
        </Status>
      </ContainerCards>
    </>
  );
};
export default Card;
