import styled from "styled-components";

export const DivP = styled.div`
  display: grid;
  grid-auto-rows: max-content;
  overflow: auto;
  background-color: #f5f7fa;
  overflow: hidden;
  overflow-y: scroll;
  width: 517px;
  height: 383px;
`;
export const Ddata = styled.p`
  stroke: none;
  width: 95px;
  display: flex;
  margin-left: 50px;
  margin-top: 10px;
  height: 20px;
  font-weight: 700;
  top: 13px;
  font-family: "Inter";
  font-style: normal;
  white-space: nowrap;
  border-radius: 2px;
`;
export const DivMain = styled.div`
  width: 100vw;
  height: 100vh;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const Header = styled.div`
`

export const DivPlanner = styled.div`
`