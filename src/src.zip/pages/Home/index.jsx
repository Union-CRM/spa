import React from "react";
import PageBody from "../../components/PageBody";

class Home extends React.Component {
  render() {
    return (
      <>
        <PageBody>
          <h1>
            Substitua este H1 pelo seu codigo durante os testes, depois remova-o
          </h1>
        </PageBody>
      </>
    );
  }
}

export default Home;
