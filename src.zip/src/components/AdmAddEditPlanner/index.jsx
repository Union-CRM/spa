import React from 'react'
import { DivModal,DivTitle,DivInfo,DivDateStartFinish,DivClocks,Input, DivButton,DivDate } from './styles'
import SingleSelect from '../Input/SingleSelect';
import InputWithName from '../Input/InputWithName';
import Headline from '../../assets/FontSystem/Headline';
import Clock from '../Input/clock'
import { MultiSelect } from '../Input/SelectMulti';
import { TagComponent } from '../TagComponent';
import ButtonDefault from '../../assets/Buttons/ButtonDefault';
import Body from '../../assets/FontSystem/Body';

const guests = [
    {
        label: "Carlos",
    },
    {
        label: "Igor",
    },
    {
        label: "Ricardo",
    },
    {
        label: "Eber",
    }
]

const AdmAddEditPlanner = ({ title }) => {
   

  return (
    <DivModal>
        <DivTitle>
            <Headline type={"Headline3"} name={title}/>
        </DivTitle>
        <DivInfo>
            <SingleSelect label={"Subject"} height={"35px"}/>
            <InputWithName label={"Client Name"}/>
            <InputWithName label={"Email"}/>
            <InputWithName label={"Business"}/>
            <InputWithName label={"Reelase Train"}/>
            <DivDateStartFinish>
                <DivClocks>
                    <DivDate>
                        <Body type={"Body2"} name={"Date"}></Body>
                    </DivDate>
                    <Input type="date" />
                </DivClocks>
                <DivClocks>
                     <Clock label={"Start"}/>
                </DivClocks>
                <DivClocks>
                     <Clock label={"End"}/>
                </DivClocks>
            </DivDateStartFinish>
            <TagComponent label={"Guest"} options={guests}  heights={"10px"}></TagComponent>
            <MultiSelect label={"Guest"} options={guests}  heights={"10px"}></MultiSelect>
            
            <SingleSelect label={"Status"} sizeSingle={"150px"} height={"35px"}/>
            <DivButton>
                <ButtonDefault type={"userSave"} name={"Save"}/>
                <ButtonDefault type={"userCancel"} name={"Cancel"}/>
            </DivButton>
        </DivInfo>
    </DivModal>
  )
}

export default AdmAddEditPlanner