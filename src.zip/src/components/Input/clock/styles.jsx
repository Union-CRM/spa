import styled from "styled-components";

export const PositionLabel = styled.div`
    margin-bottom: 10px;
`