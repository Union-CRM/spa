export const cardStatusMock = {
    INPROGRESS: "Progress",
    FINISHED: "Finished",
    CANCELED: "Canceled",
}